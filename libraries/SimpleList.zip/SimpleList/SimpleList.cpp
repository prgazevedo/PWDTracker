#include "SimpleList.h"

// All implementation in .h because avr goes crazy with templates in .cpp